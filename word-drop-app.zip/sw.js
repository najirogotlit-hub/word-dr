/* Word Drop offline cache. The page is fetched from the network first, so updates arrive as soon as there is a connection. */
const CACHE="word-drop-v2";
const CORE=["./","manifest.webmanifest","icon-192.png","icon-512.png","icon-maskable-512.png","apple-touch-icon.png"];
const EXTRA=["https://unpkg.com/peerjs@1.5.5/dist/peerjs.min.js","https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700;800&display=swap"];
const OUTSIDE=/^https:\/\/(unpkg\.com|fonts\.googleapis\.com|fonts\.gstatic\.com)\//;
self.addEventListener("install",e=>e.waitUntil((async()=>{const c=await caches.open(CACHE);await c.addAll(CORE.map(u=>new Request(u,{cache:"reload"})));
await Promise.allSettled(EXTRA.map(u=>c.add(new Request(u,{mode:"cors"}))));await self.skipWaiting()})()));
self.addEventListener("activate",e=>e.waitUntil((async()=>{for(const k of await caches.keys())if(k.startsWith("word-drop-")&&k!==CACHE)await caches.delete(k);await self.clients.claim()})()));
async function page(req){const c=await caches.open(CACHE),saved=()=>c.match("./");
const live=fetch(req.url,{cache:"no-cache"}).then(async r=>{if(r.ok&&new URL(r.url).pathname===new URL("./",self.location).pathname)await c.put("./",r.clone());return r});
try{const quick=await Promise.race([live,new Promise(ok=>setTimeout(ok,4000))]);if(quick&&quick.ok)return quick;return await saved()||await live}catch{return await saved()||Response.error()}}
async function asset(req){const c=await caches.open(CACHE),hit=await c.match(req,{ignoreVary:true});
const live=fetch(req).then(r=>{if(r.ok||r.type==="opaque")c.put(req,r.clone());return r});
if(hit){live.catch(()=>{});return hit}return live}
self.addEventListener("fetch",e=>{const req=e.request;if(req.method!=="GET")return;const url=new URL(req.url);
if(url.origin===self.location.origin){const scope=new URL("./",self.location).pathname;if(!url.pathname.startsWith(scope))return;
if(req.mode==="navigate"){if(url.pathname===scope||url.pathname===scope+"index.html"){url.search="";e.respondWith(page(new Request(url)))}return}
e.respondWith(asset(req))}else if(OUTSIDE.test(req.url))e.respondWith(asset(req))});
